document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("summarizer-form");
    const textInput = document.getElementById("text-input");
    const fileInput = document.getElementById("file-input");
    const outputBox = document.getElementById("summary-output");

    form.addEventListener("submit", async function (event) {
        event.preventDefault();
        outputBox.textContent = "Generating summary... Please wait.";

        const formData = new FormData();

        if (textInput.value.trim() !== "") {
            formData.append("text", textInput.value);
        } else if (fileInput.files.length > 0) {
            formData.append("file", fileInput.files[0]);
        } else {
            outputBox.textContent = "Please provide text or upload a file.";
            return;
        }

        try {
            const response = await fetch("/summarize", {
                method: "POST",
                body: formData,
            });

            if (!response.ok) {
                throw new Error("Network response was not ok.");
            }

            const data = await response.json();

            if (data.error) {
                outputBox.textContent = `Error: ${data.error}`;
            } else {
                outputBox.textContent = data.summary;
            }
        } catch (error) {
            outputBox.textContent = `An error occurred: ${error.message}`;
        }
    });
});
