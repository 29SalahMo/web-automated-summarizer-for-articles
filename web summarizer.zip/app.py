from flask import Flask, render_template, request, jsonify
from transformers import pipeline
import os
import fitz  # PyMuPDF for PDF handling

# Initialize the Flask app
app = Flask(__name__)

# Load the summarization model
summarizer = pipeline("summarization")

# Function to summarize text
def summarize_text(text, max_length=130, min_length=30):
    summary = summarizer(text, max_length=max_length, min_length=min_length, do_sample=False)
    return summary[0]['summary_text']

# Function to extract text from a PDF file
def extract_text_from_pdf(pdf_path):
    text = ""
    with fitz.open(pdf_path) as doc:
        for page in doc:
            text += page.get_text()
    return text

# Route for the homepage
@app.route("/")
def home():
    return render_template("index.html")

# Route for handling summarization requests
@app.route("/summarize", methods=["POST"])
def summarize():
    if "text" in request.form:
        text = request.form["text"]
        summary = summarize_text(text)
        return jsonify({"summary": summary})

    if "file" in request.files:
        file = request.files["file"]
        if file.filename.endswith(".pdf"):
            text = extract_text_from_pdf(file)
            summary = summarize_text(text)
            return jsonify({"summary": summary})
        else:
            return jsonify({"error": "Unsupported file type. Please upload a PDF file."})

    return jsonify({"error": "No input provided."})

# Run the Flask app
if __name__ == "__main__":
    app.run(debug=True)
